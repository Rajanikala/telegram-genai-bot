"""
cache.py — Simple in-memory query cache

Normalises query strings before storing so that
"What is ML?" and "what is ml?" hit the same cache entry.
"""

import re
import logging
from typing import Dict, Optional

logger = logging.getLogger(__name__)


def _normalise(query: str) -> str:
    """Lowercase, collapse whitespace, strip punctuation."""
    q = query.lower().strip()
    q = re.sub(r"[^\w\s]", "", q)
    q = re.sub(r"\s+", " ", q)
    return q


class QueryCache:
    def __init__(self) -> None:
        self._store: Dict[str, dict] = {}

    def get(self, query: str) -> Optional[dict]:
        key = _normalise(query)
        hit = self._store.get(key)
        if hit:
            logger.debug("Cache HIT for: %s", key)
        return hit

    def set(self, query: str, value: dict) -> None:
        key = _normalise(query)
        self._store[key] = value
        logger.debug("Cache SET for: %s", key)

    def clear(self) -> None:
        self._store.clear()
        logger.info("Cache cleared.")
