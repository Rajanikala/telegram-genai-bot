"""
history.py — Per-user message history (in-memory)

Keeps the last `max_entries` interactions per user.
Used by /summarize and for future context injection.
"""

from collections import defaultdict, deque
from typing import List


class MessageHistory:
    def __init__(self, max_entries: int = 3) -> None:
        self.max_entries = max_entries
        # user_id (int) → deque of string entries
        self._store: dict = defaultdict(lambda: deque(maxlen=self.max_entries))

    def add(self, user_id: int, entry: str) -> None:
        """Append a new interaction entry for the given user."""
        self._store[user_id].append(entry)

    def get(self, user_id: int) -> List[str]:
        """Return all stored entries for this user (oldest first)."""
        return list(self._store[user_id])

    def clear(self, user_id: int) -> None:
        """Wipe history for a specific user."""
        self._store[user_id].clear()
