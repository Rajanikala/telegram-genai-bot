"""
rag.py — Mini-RAG pipeline using Groq (free) for generation
Embeddings use sentence-transformers locally (no API needed)
"""

import os
import re
import sqlite3
import logging
import numpy as np
from pathlib import Path
from typing import List, Dict

from sentence_transformers import SentenceTransformer
from groq import Groq

logger = logging.getLogger(__name__)

DB_PATH = "rag_store.db"
EMBED_MODEL = "all-MiniLM-L6-v2"
CHUNK_SIZE = 300
CHUNK_OVERLAP = 50
TOP_K = 3


class RAGSystem:
    def __init__(self, knowledge_dir: str = "knowledge") -> None:
        self.knowledge_dir = Path(knowledge_dir)
        self.client = Groq(api_key=os.getenv("GROQ_API_KEY"))
        logger.info("Loading embedding model: %s", EMBED_MODEL)
        self.embedder = SentenceTransformer(EMBED_MODEL)
        self._init_db()
        self._index_documents()

    def _init_db(self) -> None:
        self.conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS chunks (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                source   TEXT NOT NULL,
                content  TEXT NOT NULL,
                vector   BLOB NOT NULL
            )
            """
        )
        self.conn.commit()

    def _db_is_empty(self) -> bool:
        return self.conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0] == 0

    def _load_documents(self) -> List[Dict[str, str]]:
        docs = []
        for path in self.knowledge_dir.glob("*"):
            if path.suffix in {".md", ".txt"}:
                text = path.read_text(encoding="utf-8")
                docs.append({"source": path.name, "content": text})
        logger.info("Loaded %d documents from %s", len(docs), self.knowledge_dir)
        return docs

    def _chunk_text(self, text: str) -> List[str]:
        chunks, start = [], 0
        while start < len(text):
            end = min(start + CHUNK_SIZE, len(text))
            chunks.append(text[start:end].strip())
            if end == len(text):
                break
            start += CHUNK_SIZE - CHUNK_OVERLAP
        return [c for c in chunks if len(c) > 20]

    def _index_documents(self) -> None:
        if not self._db_is_empty():
            logger.info("Embeddings already indexed — skipping.")
            return

        docs = self._load_documents()
        if not docs:
            logger.warning("No documents found in '%s'.", self.knowledge_dir)
            return

        rows = []
        for doc in docs:
            for chunk in self._chunk_text(doc["content"]):
                rows.append((doc["source"], chunk))

        logger.info("Embedding %d chunks...", len(rows))
        texts = [r[1] for r in rows]
        vectors = self.embedder.encode(texts, show_progress_bar=False, batch_size=32)

        self.conn.executemany(
            "INSERT INTO chunks (source, content, vector) VALUES (?, ?, ?)",
            [
                (src, content, self._to_blob(vec))
                for (src, content), vec in zip(rows, vectors)
            ],
        )
        self.conn.commit()
        logger.info("Indexed %d chunks successfully.", len(rows))

    @staticmethod
    def _to_blob(vec: np.ndarray) -> bytes:
        return vec.astype(np.float32).tobytes()

    @staticmethod
    def _from_blob(blob: bytes) -> np.ndarray:
        return np.frombuffer(blob, dtype=np.float32)

    def _retrieve(self, query: str, top_k: int = TOP_K) -> List[Dict]:
        query_vec = self.embedder.encode([query], show_progress_bar=False)[0]
        rows = self.conn.execute(
            "SELECT source, content, vector FROM chunks"
        ).fetchall()

        scored = []
        for source, content, blob in rows:
            chunk_vec = self._from_blob(blob)
            score = float(
                np.dot(query_vec, chunk_vec)
                / (np.linalg.norm(query_vec) * np.linalg.norm(chunk_vec) + 1e-9)
            )
            scored.append({"source": source, "content": content, "score": score})

        scored.sort(key=lambda x: x["score"], reverse=True)
        return scored[:top_k]

    def query(self, user_query: str) -> Dict[str, str]:
        hits = self._retrieve(user_query)
        if not hits:
            return {
                "answer": "I couldn't find relevant information in the knowledge base.",
                "source": "—",
                "snippet": "",
            }

        context_parts = [f"[{h['source']}]\n{h['content']}" for h in hits]
        context = "\n\n---\n\n".join(context_parts)

        system_prompt = (
            "You are a helpful assistant. "
            "Answer the user's question ONLY using the provided context. "
            "Be concise (2-4 sentences). "
            "If the answer is not in the context, say so honestly."
        )
        user_message = f"Context:\n{context}\n\nQuestion: {user_query}"

        response = self.client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            max_tokens=300,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message},
            ],
        )
        answer = response.choices[0].message.content.strip()
        best = hits[0]
        snippet = re.sub(r"\s+", " ", best["content"])[:120] + "..."

        return {
            "answer": answer,
            "source": best["source"],
            "snippet": snippet,
        }