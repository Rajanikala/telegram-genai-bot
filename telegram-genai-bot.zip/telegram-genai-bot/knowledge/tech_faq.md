# Tech FAQ — Common Questions & Answers

## What is an API?
An API (Application Programming Interface) is a set of rules that allows two software applications to communicate. It defines the requests that can be made, how to make them, and the format of responses. REST and GraphQL are popular API styles.

## What is the difference between SQL and NoSQL databases?
**SQL (Relational)** — Data stored in tables with fixed schema. Great for structured data and complex joins. Examples: PostgreSQL, MySQL, SQLite.
**NoSQL** — Flexible schema, designed for scale. Includes document stores (MongoDB), key-value stores (Redis), wide-column (Cassandra), and graph DBs (Neo4j).

## What is Docker?
Docker is a containerisation platform that packages an application and its dependencies into a portable container. Containers run consistently across different environments (laptop, server, cloud), solving the "works on my machine" problem.

## What is Git?
Git is a distributed version control system. It tracks changes to code, allows collaboration, and maintains full history. Key commands:
- `git clone` — Copy a repository
- `git commit` — Save changes locally
- `git push` / `git pull` — Sync with remote
- `git branch` — Manage branches

## What is CI/CD?
Continuous Integration (CI) automatically tests code on every push. Continuous Deployment (CD) automatically deploys passing builds to production. Tools: GitHub Actions, GitLab CI, Jenkins, CircleCI.

## What is the Cloud?
Cloud computing provides on-demand computing resources (servers, storage, databases, networking) over the internet. Major providers:
- **AWS** (Amazon Web Services)
- **Google Cloud Platform (GCP)**
- **Microsoft Azure**

## What is a REST API?
REST (Representational State Transfer) is an architectural style for APIs using HTTP verbs:
- **GET** — Retrieve data
- **POST** — Create data
- **PUT/PATCH** — Update data
- **DELETE** — Remove data
Responses are typically in JSON format.

## What is Kubernetes?
Kubernetes (K8s) is an open-source container orchestration system. It automates deploying, scaling, and managing Docker containers across clusters of machines.

## What is a VPN?
A Virtual Private Network (VPN) encrypts your internet traffic and routes it through a secure server, hiding your IP address and protecting data on public networks.

## What is machine learning inference?
Inference is the process of using a trained ML model to make predictions on new data. As opposed to training (which learns from data), inference is the production stage where the model runs in real time.
