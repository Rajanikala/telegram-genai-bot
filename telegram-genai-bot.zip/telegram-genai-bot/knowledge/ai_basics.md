# Machine Learning & AI Basics

## What is Machine Learning?
Machine Learning (ML) is a branch of artificial intelligence where systems learn from data to improve their performance on tasks without being explicitly programmed. Instead of following hard-coded rules, ML models discover patterns from examples.

## Types of Machine Learning

**Supervised Learning** — The model trains on labelled data (input-output pairs). Examples: spam detection, image classification, price prediction.

**Unsupervised Learning** — No labels provided; the model finds hidden structure. Examples: customer segmentation (k-means clustering), topic modelling (LDA).

**Reinforcement Learning** — An agent takes actions in an environment and learns via rewards and penalties. Examples: game-playing AIs (AlphaGo), robotics.

## Common Algorithms
- **Linear Regression** — Predicts a continuous output.
- **Logistic Regression** — Binary or multi-class classification.
- **Decision Trees / Random Forests** — Ensemble methods, robust to noise.
- **Support Vector Machines (SVM)** — Finds optimal decision boundary.
- **Neural Networks / Deep Learning** — Multi-layered architectures for complex patterns (images, text, audio).

## Key Concepts
- **Overfitting** — Model memorises training data, fails on new data. Fix: regularisation, more data, cross-validation.
- **Underfitting** — Model is too simple to capture patterns. Fix: more complex model, more features.
- **Feature Engineering** — Transforming raw data into useful inputs for the model.
- **Cross-Validation** — Technique to estimate generalisation performance (e.g., k-fold CV).

## What is Deep Learning?
Deep Learning is a subfield of ML using artificial neural networks with many layers. It excels at unstructured data (images, text, speech). Architectures include CNNs (vision), RNNs/LSTMs (sequences), and Transformers (NLP, multimodal).

## What is a Large Language Model (LLM)?
An LLM is a deep learning model trained on massive text corpora to generate and understand natural language. Examples include GPT-4, Claude, Gemini, and Mistral. They are used for chatbots, summarisation, code generation, and more.
