# TechCorp Employee Handbook — Key Policies

## Work Hours
- Standard office hours: 9:00 AM – 6:00 PM, Monday to Friday.
- Flexible start times are allowed between 8:00 AM and 10:30 AM with manager approval.
- Remote work is permitted up to 3 days per week for full-time employees.

## Leave Policy

| Leave Type          | Entitlement per Year |
|---------------------|----------------------|
| Annual / Paid Leave  | 18 working days      |
| Sick Leave           | 10 working days      |
| Casual Leave         | 6 working days       |
| Maternity Leave      | 26 weeks (paid)      |
| Paternity Leave      | 2 weeks (paid)       |
| Study / Exam Leave   | 5 working days       |

Unused annual leave may be carried over up to 10 days into the next calendar year.

## Expense Reimbursement
- Employees must submit expense claims within **30 days** of incurring the expense.
- Receipts are mandatory for any expense above ₹500.
- Travel booked outside the company portal will not be reimbursed.
- Daily meal allowance during business travel: ₹800 per day.

## Code of Conduct
All employees are expected to:
- Treat colleagues with respect and professionalism.
- Maintain confidentiality of company and client data.
- Report conflicts of interest to HR promptly.
- Not engage in harassment, discrimination, or workplace violence.

Violations may result in disciplinary action up to and including termination.

## IT & Data Security
- Employees must use strong, unique passwords and enable two-factor authentication.
- Company data must not be stored on personal devices without VPN.
- Immediately report lost devices or suspected data breaches to security@techcorp.com.

## Performance Reviews
Performance appraisals are conducted bi-annually: in June and December.
Salary revisions are linked to appraisal outcomes and are effective from January each year.

## Grievance Redressal
Employees may raise concerns via the HR portal or by emailing hr@techcorp.com.
All grievances will be acknowledged within 2 business days and resolved within 15 business days.
