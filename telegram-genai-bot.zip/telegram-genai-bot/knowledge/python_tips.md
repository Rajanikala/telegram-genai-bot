# Python Programming Tips & Best Practices

## Virtual Environments
Always isolate project dependencies using a virtual environment.

```bash
python -m venv venv
source venv/bin/activate        # Linux/macOS
venv\Scripts\activate           # Windows
pip install -r requirements.txt
```

## Writing Clean Code

**Use type hints** — Makes code self-documenting and catches bugs early.
```python
def greet(name: str) -> str:
    return f"Hello, {name}!"
```

**List comprehensions** — Prefer them over loops for simple transformations.
```python
squares = [x**2 for x in range(10)]
```

**Context managers** — Always use `with` for file I/O to ensure proper cleanup.
```python
with open("data.txt", "r") as f:
    content = f.read()
```

## Common Data Libraries

| Library     | Purpose                          |
|-------------|----------------------------------|
| NumPy       | Numerical arrays and math        |
| Pandas      | DataFrames and data wrangling    |
| Matplotlib  | Plotting and visualisation       |
| Scikit-learn| Classical ML algorithms          |
| PyTorch     | Deep learning                    |

## Error Handling
Use specific exceptions and always log errors.
```python
try:
    result = risky_operation()
except ValueError as e:
    logging.error("Invalid value: %s", e)
except Exception as e:
    logging.exception("Unexpected error")
```

## Working with APIs
Use the `requests` library or `httpx` (async) for HTTP calls.
```python
import requests
response = requests.get("https://api.example.com/data", timeout=10)
response.raise_for_status()
data = response.json()
```

## Performance Tips
- Use **generators** (`yield`) for large datasets — avoids loading all data into memory.
- Profile before optimising: `python -m cProfile script.py`
- For CPU-bound tasks, use `multiprocessing`; for I/O-bound, use `asyncio`.

## f-Strings (Python 3.6+)
```python
name = "Alice"
score = 97.5
print(f"{name} scored {score:.1f}%")   # Alice scored 97.5%
```
