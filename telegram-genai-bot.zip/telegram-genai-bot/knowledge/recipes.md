# Popular Indian Recipes

## Butter Chicken (Murgh Makhani)

**Ingredients (serves 4)**
- 700 g boneless chicken, cubed
- 1 cup plain yoghurt
- 1 tbsp ginger-garlic paste
- 1 tsp red chilli powder
- 400 g crushed tomatoes
- 150 ml fresh cream
- 2 tbsp butter
- 1 tsp garam masala, cumin, coriander powder each
- Salt to taste

**Method**
1. Marinate chicken in yoghurt, ginger-garlic paste, chilli powder, and salt for 30 minutes.
2. Grill or pan-fry chicken until cooked through. Set aside.
3. In the same pan melt butter, add spices, then tomatoes. Simmer 15 minutes.
4. Blend sauce until smooth. Return to pan, add cream and chicken.
5. Simmer 10 minutes. Garnish with cream and coriander. Serve with naan or rice.

---

## Dal Tadka

**Ingredients (serves 4)**
- 200 g yellow toor dal (split pigeon peas)
- 1 onion, finely chopped
- 2 tomatoes, chopped
- 1 tsp cumin seeds
- 1 tsp turmeric
- 1 tsp red chilli powder
- 2 cloves garlic, minced
- 2 tbsp ghee
- Salt and coriander to taste

**Method**
1. Wash and pressure-cook dal with turmeric and 3 cups water for 3–4 whistles.
2. Heat ghee; splutter cumin seeds, add garlic, onion, fry till golden.
3. Add tomatoes and spices; cook till oil separates.
4. Mix in cooked dal, simmer 5 minutes. Adjust consistency.
5. Finish with a tadka of ghee, dried red chillies, and cumin poured on top.

---

## Masala Chai

**Ingredients (2 cups)**
- 2 cups water
- 1 cup whole milk
- 2 tsp black tea leaves (Assam / CTC)
- 1 tsp sugar (or to taste)
- 3 green cardamom pods, crushed
- 1 small piece ginger, grated
- 1 cinnamon stick
- 2 cloves

**Method**
1. Bring water to boil with spices and ginger.
2. Add tea leaves, simmer 2 minutes.
3. Add milk and sugar; bring back to a gentle boil.
4. Strain into cups. Serve hot.

---

## Paneer Tikka (Starter)

**Ingredients**
- 300 g paneer, cubed
- 1 bell pepper and 1 onion, cubed
- 3 tbsp thick yoghurt
- 1 tbsp tandoori masala
- 1 tsp chaat masala
- 1 tbsp lemon juice
- 1 tbsp oil

**Method**
1. Mix yoghurt with spices, lemon juice, and oil to form marinade.
2. Coat paneer and vegetables, marinate 1 hour.
3. Skewer and grill / air-fry at 200°C for 15–18 minutes, turning once.
4. Sprinkle chaat masala and serve with green chutney.
