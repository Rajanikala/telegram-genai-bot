"""
vision.py — Image description using Groq (free)
Uses llama-4-scout vision model to generate caption and tags
"""

import os
import base64
import json
import logging
from typing import Dict, List

from groq import Groq

logger = logging.getLogger(__name__)


def describe_image(image_bytes: bytes) -> Dict[str, object]:
    client = Groq(api_key=os.getenv("GROQ_API_KEY"))

    b64 = base64.b64encode(image_bytes).decode("utf-8")
    data_url = f"data:image/jpeg;base64,{b64}"

    prompt = (
        "Analyse this image and respond with ONLY valid JSON (no markdown fences) "
        "in this exact format:\n"
        '{"caption": "<one-sentence description>", "tags": ["<tag1>", "<tag2>", "<tag3>"]}\n'
        "The caption should be vivid and informative. "
        "Tags should be short relevant keywords."
    )

    response = client.chat.completions.create(
        model="meta-llama/llama-4-scout-17b-16e-instruct",
        max_tokens=200,
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {"url": data_url},
                    },
                ],
            }
        ],
    )

    raw = response.choices[0].message.content.strip()
    logger.debug("Vision raw response: %s", raw)

    try:
        clean = raw.replace("```json", "").replace("```", "").strip()
        parsed = json.loads(clean)
        caption: str = parsed.get("caption", "No caption available.")
        tags: List[str] = parsed.get("tags", [])[:3]
    except json.JSONDecodeError:
        logger.warning("Failed to parse JSON from vision response; using fallback.")
        caption = raw[:300]
        tags = []

    return {"caption": caption, "tags": tags}
