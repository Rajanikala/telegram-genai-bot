"""
Hybrid GenAI Telegram Bot
Supports:
  - /ask <query>   → Mini-RAG over local knowledge base
  - /image         → Describes uploaded images (Vision AI)
  - /summarize     → Summarizes recent conversation
  - /help          → Usage instructions
"""

import os
import io
import logging
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
)

from rag import RAGSystem
from vision import describe_image
from history import MessageHistory
from cache import QueryCache

load_dotenv()

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

rag = RAGSystem(knowledge_dir="knowledge")
history = MessageHistory(max_entries=3)
cache = QueryCache()


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "*Welcome to the Hybrid GenAI Bot!*\n\n"
        "I can answer questions from a knowledge base *or* describe images you send.\n\n"
        "Commands:\n"
        "  /ask _<your question>_ — RAG-powered Q&A\n"
        "  /image — then send a photo to get a caption + tags\n"
        "  /summarize — recap your last 3 interactions\n"
        "  /help — show this message again",
        parse_mode="Markdown",
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "*Bot Help*\n\n"
        "*/ask <query>*\n"
        "Ask anything covered in the knowledge base.\n"
        "_Example:_ `/ask What is machine learning?`\n\n"
        "*/image*\n"
        "Send this command, then upload a photo.\n"
        "I'll return a caption and keyword tags.\n\n"
        "*/summarize*\n"
        "Get a short summary of your last 3 interactions.\n\n"
        "*/help*  Show this help message.",
        parse_mode="Markdown",
    )


async def ask(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    query = " ".join(context.args).strip()

    if not query:
        await update.message.reply_text(
            "Please include your question.\n"
            "_Example:_ `/ask What is machine learning?`",
            parse_mode="Markdown",
        )
        return

    cached = cache.get(query)
    if cached:
        logger.info("Cache hit for query: %s", query)
        history.add(user_id, f"Q: {query}\nA: {cached['answer']}")
        await update.message.reply_text(
            f"*(Cached)*\n\n{cached['answer']}\n\n"
            f"*Source:* `{cached['source']}`",
            parse_mode="Markdown",
        )
        return

    thinking_msg = await update.message.reply_text("Searching knowledge base…")

    try:
        result = rag.query(query)
    except Exception as exc:
        logger.error("RAG query failed: %s", exc)
        await thinking_msg.edit_text(" Something went wrong while searching. Please try again.")
        return

    answer = result["answer"]
    source = result["source"]
    snippet = result.get("snippet", "")

    cache.set(query, {"answer": answer, "source": source})
    history.add(user_id, f"Q: {query}\nA: {answer}")

    reply = f"*Answer:*\n\n{answer}\n\n*Source:* `{source}`"
    if snippet:
        reply += f"\n\n*Relevant snippet:*\n_{snippet}_"

    await thinking_msg.edit_text(reply, parse_mode="Markdown")


async def image_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data["awaiting_image"] = True
    await update.message.reply_text(
        "Ready! Please *send your image* now and I'll describe it.",
        parse_mode="Markdown",
    )


async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    thinking_msg = await update.message.reply_text("🔍 Analysing image…")

    try:
        photo = update.message.photo[-1]
        tg_file = await context.bot.get_file(photo.file_id)
        buf = io.BytesIO()
        await tg_file.download_to_memory(buf)
        image_bytes = buf.getvalue()
        result = describe_image(image_bytes)
    except Exception as exc:
        logger.error("Vision pipeline failed: %s", exc)
        await thinking_msg.edit_text("⚠️ Could not process the image. Please try again.")
        return

    caption = result["caption"]
    tags = result["tags"]

    hist_entry = f"[Image] Caption: {caption} | Tags: {', '.join(tags)}"
    history.add(user_id, hist_entry)
    context.user_data["awaiting_image"] = False

    await thinking_msg.edit_text(
        f"*Image Description:*\n\n{caption}\n\n"
        f"*Tags:* {', '.join(f'`{t}`' for t in tags)}",
        parse_mode="Markdown",
    )


async def summarize(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    entries = history.get(user_id)

    if not entries:
        await update.message.reply_text(
            "No history yet! Use /ask or send an image first."
        )
        return

    from groq import Groq
    client = Groq(api_key=os.getenv("GROQ_API_KEY"))
    history_text = "\n\n".join(entries)

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        max_tokens=200,
        messages=[
            {
                "role": "system",
                "content": "You are a concise assistant. Summarise the following user interactions in 2-3 sentences.",
            },
            {"role": "user", "content": history_text},
        ],
    )
    summary = response.choices[0].message.content.strip()

    await update.message.reply_text(
        f"*Conversation Summary:*\n\n{summary}",
        parse_mode="Markdown",
    )


def main() -> None:
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token:
        raise EnvironmentError("TELEGRAM_BOT_TOKEN is not set in your .env file.")

    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("ask", ask))
    app.add_handler(CommandHandler("image", image_command))
    app.add_handler(CommandHandler("summarize", summarize))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))

    logger.info("Bot is running. Press Ctrl-C to stop.")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()